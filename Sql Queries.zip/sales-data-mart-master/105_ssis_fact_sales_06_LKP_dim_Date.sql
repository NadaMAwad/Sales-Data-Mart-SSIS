SELECT
	date_key AS order_date_key,
	full_date
FROM dim_date