SELECT
	territory_key,
	territory_id
FROM dim_territory
WHERE is_current = 1